int main_mcmc_split_info(int, char** argv);

int
main(int argc, char *argv[])
{
    return main_mcmc_split_info(argc, argv);
}
