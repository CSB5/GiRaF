#ifndef _LABEL_TYPES_H_
#define _LABEL_TYPES_H_

typedef int left_label_t;
typedef int right_label_t;
typedef int tree_label_t;
typedef int edge_label_t;

#endif
