
int main_build_incompat_graph(int, char**);

int
main(int argc, char * argv[])
{
    return main_build_incompat_graph(argc, argv);
}
