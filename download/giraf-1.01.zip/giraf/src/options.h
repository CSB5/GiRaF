#ifndef OPTIONS_H
#define OPTIONS_H
#include <getopt.h>

#ifdef __GNUC__
#   define MAYBE_UNUSED __attribute__((used))
#else
#   define MAYBE_UNUSED
#endif

#endif

